from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response

from services.graph_service import GrafoService

router = APIRouter()
_service = GrafoService()


@router.get("/grafos/locais")
def listar_locais():
    return _service.listar_locais()


@router.get("/grafos/rota")
def calcular_menor_rota(
    origem: str = Query("Hotel CheckQ (Ponta Verde)", description="Ponto de partida"),
    destino: str = Query("Aeroporto Zumbi dos Palmares", description="Ponto de destino"),
):
    try:
        return _service.calcular_rota(origem=origem, destino=destino)
    except ValueError as erro:
        raise HTTPException(status_code=400, detail=str(erro))


@router.get("/grafos/mapa")
def visualizar_mapa_grafo(
    origem: str = Query("Hotel CheckQ (Ponta Verde)", description="Ponto de partida"),
    destino: str = Query("Aeroporto Zumbi dos Palmares", description="Ponto de destino"),
):
    try:
        imagem_png = _service.gerar_mapa_rota(origem=origem, destino=destino)
        return Response(content=imagem_png, media_type="image/png")
    except ValueError as erro:
        raise HTTPException(status_code=400, detail=str(erro))