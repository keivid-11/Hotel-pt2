from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response

from repository.historico_chekin_repository import HistoricoCheckinRepository
from services.ordination_service import OrdenacaoService

router = APIRouter()

_historico_repo = HistoricoCheckinRepository()
_service = OrdenacaoService(_historico_repo)


@router.get("/historico/ordenado")
def listar_historico_ordenado(
    algoritmo: str = Query("quicksort", description="bubble, insertion, selection ou quicksort"),
    criterio: str = Query("nome_hospede", description="nome_hospede, numero_quarto ou horario_entrada"),
):
    try:
        return _service.ordenar_historico(algoritmo=algoritmo, criterio=criterio)
    except ValueError as erro:
        raise HTTPException(status_code=400, detail=str(erro))


@router.get("/ordenacao/comparativo")
def grafico_comparativo_ordenacao():
    imagem_png = _service.gerar_grafico_comparativo()
    return Response(content=imagem_png, media_type="image/png")