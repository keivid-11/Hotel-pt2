from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from datetime import datetime

from services.checkin_service import (
    CheckinService,
    QuartoJaOcupadoError,
    NumeroQuartoInvalidoError,
    FilaVaziaError,
    PilhaVaziaError,
    DataEntradaInvalidaError,
    DataSaidaInvalidaError,
)
from repository.checkin_repository import CheckinRepository

router = APIRouter()

_repository = CheckinRepository()
_service = CheckinService(_repository)


class CheckinCreateSchema(BaseModel):
    nome_hospede: str
    numero_quarto: int
    horario_entrada: datetime
    horario_saida: datetime
    prioritario: bool = False


@router.post("/fila")
def solicitar_checkin(dados: CheckinCreateSchema):
    try:
        checkin = _service.solicitar_checkin(
            nome_hospede=dados.nome_hospede,
            numero_quarto=dados.numero_quarto,
            horario_entrada=dados.horario_entrada,
            horario_saida=dados.horario_saida,
            prioritario=dados.prioritario,
        )
        return checkin
    except ValueError as erro:
        raise HTTPException(status_code=400, detail=str(erro))
    except DataEntradaInvalidaError as erro:
        raise HTTPException(status_code=400, detail=str(erro))
    except DataSaidaInvalidaError as erro:
        raise HTTPException(status_code=400, detail=str(erro))
    except NumeroQuartoInvalidoError as erro:
        raise HTTPException(status_code=400, detail=str(erro))
    except QuartoJaOcupadoError as erro:
        raise HTTPException(status_code=409, detail=str(erro))


@router.get("/fila")
def listar_fila():
    return _service.listar_fila()


@router.delete("/fila/proximo")
def atender_proximo():
    try:
        return _service.atender_proximo()
    except FilaVaziaError as erro:
        raise HTTPException(status_code=404, detail=str(erro))


@router.post("/fila/desfazer")
def desfazer_ultimo_atendimento():
    try:
        return _service.desfazer_ultimo_atendimento()
    except PilhaVaziaError as erro:
        raise HTTPException(status_code=404, detail=str(erro))


@router.get("/hash/quartos")
def inspecionar_tabela_hash():
    return _service.inspecionar_tabela_hash()