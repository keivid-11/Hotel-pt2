from datetime import datetime
from domain.checkin import Checkin
from repository.checkin_repository import CheckinRepository
from estructures.estructures_leneares import DequeFilaCheckin, PilhaDesfazer
from estructures.tableHash import TabelaHash


class QuartoJaOcupadoError(Exception):
    """Levantada quando já existe um check-in ativo para esse quarto."""


class FilaVaziaError(Exception):
    """Levantada quando a recepção tenta atender e não há ninguém na fila."""


class PilhaVaziaError(Exception):
    """Levantada quando não há atendimento recente para desfazer."""


class NumeroQuartoInvalidoError(Exception):
    """Levantada quando o número do quarto está fora do limite do hotel."""


class DataEntradaInvalidaError(Exception):
    """Levantada quando a data de entrada é inválida (ex: no passado)."""


class DataSaidaInvalidaError(Exception):
    """Levantada quando a data de saída é anterior à de entrada."""


class CheckinService:
    total_quartos = 100

    def __init__(self, repository: CheckinRepository):
        self._repository = repository
        self._deque_fila = DequeFilaCheckin()
        self._pilha_desfazer = PilhaDesfazer()
        self._hash_quartos = TabelaHash(capacidade=31)
        self._sincronizar_estruturas()

    def _sincronizar_estruturas(self) -> None:
        """Carrega os check-ins pendentes do SQLite para o Deque e para a Tabela Hash."""
        self._deque_fila.limpar()
        self._hash_quartos.limpar()
        pendentes = self._repository.listar_todos()
        for checkin in pendentes:
            self._deque_fila.inserir_fim(checkin)
            self._hash_quartos.inserir(checkin.numero_quarto, checkin.nome_hospede)

    def _processar_expirados(self) -> None:
        """Remove expirados do banco e atualiza a Tabela Hash e o Deque se houver alterações."""
        expirados = self._repository.remover_expirados()
        if expirados:
            for item in expirados:
                self._hash_quartos.remover(item.numero_quarto)
            # Reconstroi o Deque mantendo a ordem atual sem os expirados
            ids_expirados = {item.id for item in expirados}
            restantes = [c for c in self._deque_fila.para_lista() if c.id not in ids_expirados]
            self._deque_fila.limpar()
            for c in restantes:
                self._deque_fila.inserir_fim(c)

    def solicitar_checkin(
        self,
        nome_hospede: str,
        numero_quarto: int,
        horario_entrada: datetime,
        horario_saida: datetime,
        prioritario: bool = False,
    ) -> Checkin:
        if not nome_hospede or not nome_hospede.strip():
            raise ValueError("O nome do hóspede não pode ser vazio.")

        if numero_quarto < 1 or numero_quarto > self.total_quartos:
            raise NumeroQuartoInvalidoError(
                f"Número do quarto inválido. O hotel possui até {self.total_quartos} quartos disponíveis."
            )

        if horario_entrada < datetime.now(horario_entrada.tzinfo):
            raise DataEntradaInvalidaError(
                "A data de entrada não pode ser no passado."
            )

        if horario_saida < horario_entrada:
            raise DataSaidaInvalidaError(
                "A data de saída não pode ser antes da de entrada."
            )

        # Libera quartos expirados antes de consultar a Tabela Hash
        self._processar_expirados()

        # Consulta O(1) na Tabela Hash
        if self._hash_quartos.contem(numero_quarto):
            hospede_atual = self._hash_quartos.buscar(numero_quarto)
            raise QuartoJaOcupadoError(
                f"O quarto {numero_quarto} já está ocupado por {hospede_atual}."
            )

        novo_checkin = Checkin(
            nome_hospede=nome_hospede,
            numero_quarto=numero_quarto,
            horario_entrada=horario_entrada,
            horario_saida=horario_saida,
        )
        salvo = self._repository.adicionar(novo_checkin)

        if prioritario:
            self._deque_fila.inserir_inicio(salvo)
        else:
            self._deque_fila.inserir_fim(salvo)

        self._hash_quartos.inserir(salvo.numero_quarto, salvo.nome_hospede)
        return salvo

    def atender_proximo(self) -> Checkin:
        self._processar_expirados()

        if self._deque_fila.esta_vazia():
            raise FilaVaziaError("Não há check-ins aguardando na fila.")

        atendido = self._deque_fila.remover_inicio()
        self._hash_quartos.remover(atendido.numero_quarto)
        self._pilha_desfazer.empilhar(atendido)

        self._repository.proximo()
        return atendido

    def desfazer_ultimo_atendimento(self) -> Checkin:
        """Desempilha (LIFO) o último check-in atendido e devolve ao início do Deque."""
        if self._pilha_desfazer.esta_vazia():
            raise PilhaVaziaError("Nenhum check-in recente disponível para desfazer.")

        ultimo = self._pilha_desfazer.desempilhar()

        restaurado = Checkin(
            nome_hospede=ultimo.nome_hospede,
            numero_quarto=ultimo.numero_quarto,
            horario_entrada=ultimo.horario_entrada,
            horario_saida=ultimo.horario_saida,
        )
        salvo = self._repository.adicionar(restaurado)
        self._deque_fila.inserir_inicio(salvo)
        self._hash_quartos.inserir(salvo.numero_quarto, salvo.nome_hospede)
        return salvo

    def listar_fila(self) -> list[Checkin]:
        self._processar_expirados()
        return self._deque_fila.para_lista()

    def inspecionar_tabela_hash(self) -> dict:
        self._processar_expirados()
        return self._hash_quartos.estado_tabela()