import io
import matplotlib
matplotlib.use("Agg")  # Modo headless para servidores web (FastAPI)
import matplotlib.pyplot as plt

from repository.historico_chekin_repository import HistoricoCheckinRepository
from estructures.ordination import (
    bubble_sort,
    insertion_sort,
    selection_sort,
    quick_sort,
    gerar_massa_checkins_simulados,
)


class OrdenacaoService:
    def __init__(self, historico_repository: HistoricoCheckinRepository):
        self._historico_repo = historico_repository

    def ordenar_historico(self, algoritmo: str = "quicksort", criterio: str = "nome_hospede") -> dict:
        registros = self._historico_repo.listar_historico()

        # Converte objetos ORM para dicionários serializáveis
        dados = [
            {
                "id": r.id,
                "nome_hospede": r.nome_hospede,
                "numero_quarto": r.numero_quarto,
                "horario_entrada": r.horario_entrada.isoformat(),
                "horario_saida": r.horario_saida.isoformat(),
            }
            for r in registros
        ]

        chaves = {
            "nome_hospede": lambda x: x["nome_hospede"].lower(),
            "numero_quarto": lambda x: x["numero_quarto"],
            "horario_entrada": lambda x: x["horario_entrada"],
        }

        if criterio not in chaves:
            raise ValueError(f"Critério inválido: {criterio}. Use: nome_hospede, numero_quarto ou horario_entrada.")

        algoritmos = {
            "bubble": bubble_sort,
            "insertion": insertion_sort,
            "selection": selection_sort,
            "quicksort": quick_sort,
        }

        algo_key = algoritmo.lower()
        if algo_key not in algoritmos:
            raise ValueError(f"Algoritmo inválido: {algoritmo}. Use: bubble, insertion, selection ou quicksort.")

        resultado = algoritmos[algo_key](dados, chaves[criterio])

        return {
            "algoritmo_utilizado": resultado.algoritmo,
            "criterio": criterio,
            "total_registros": len(resultado.dados),
            "tempo_execucao_ms": round(resultado.tempo_ms, 4),
            "comparacoes_realizadas": resultado.comparacoes,
            "dados": resultado.dados,
        }

    def gerar_grafico_comparativo(self) -> bytes:
        """
        Executa os 4 algoritmos sobre diferentes volumes de check-ins
        e gera um gráfico comparativo (Tempo x Tamanho da Entrada e Comparações) via Matplotlib.
        """
        tamanhos = [50, 150, 300, 500, 800]
        tempos = {
            "Bubble Sort": [],
            "Insertion Sort": [],
            "Selection Sort": [],
            "QuickSort": [],
        }
        comparacoes = {
            "Bubble Sort": [],
            "Insertion Sort": [],
            "Selection Sort": [],
            "QuickSort": [],
        }

        chave_ordenacao = lambda x: x["nome_hospede"]

        for n in tamanhos:
            massa = gerar_massa_checkins_simulados(n)

            res_bubble = bubble_sort(massa, chave_ordenacao)
            res_insertion = insertion_sort(massa, chave_ordenacao)
            res_selection = selection_sort(massa, chave_ordenacao)
            res_quick = quick_sort(massa, chave_ordenacao)

            for res in (res_bubble, res_insertion, res_selection, res_quick):
                tempos[res.algoritmo].append(res.tempo_ms)
                comparacoes[res.algoritmo].append(res.comparacoes)

        # Criação da figura com 2 subplots lado a lado
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5))
        fig.suptitle(
            "Hotel CheckQ — Comparativo de Desempenho dos Algoritmos de Ordenação",
            fontsize=14,
            fontweight="bold",
        )

        cores = {
            "Bubble Sort": "#ef4444",
            "Insertion Sort": "#f59e0b",
            "Selection Sort": "#3b82f6",
            "QuickSort": "#10b981",
        }

        # Gráfico 1: Tempo de Execução (ms)
        for nome_algo, lista_tempos in tempos.items():
            ax1.plot(tamanhos, lista_tempos, marker="o", linewidth=2, label=nome_algo, color=cores[nome_algo])

        ax1.set_title("Tempo de Execução (ms) x Qtd. de Check-ins")
        ax1.set_xlabel("Quantidade de Registros (N)")
        ax1.set_ylabel("Tempo (milissegundos)")
        ax1.grid(True, linestyle="--", alpha=0.5)
        ax1.legend()

        # Gráfico 2: Número de Comparações no maior volume (N = 800)
        nomes_algos = list(comparacoes.keys())
        comps_max = [comparacoes[nome][-1] for nome in nomes_algos]
        barras = ax2.bar(nomes_algos, comps_max, color=[cores[n] for n in nomes_algos])

        ax2.set_title(f"Total de Comparações (para N = {tamanhos[-1]} registros)")
        ax2.set_ylabel("Número de Comparações")
        ax2.grid(True, axis="y", linestyle="--", alpha=0.5)

        for barra in barras:
            altura = barra.get_height()
            ax2.annotate(
                f"{altura:,}".replace(",", "."),
                xy=(barra.get_x() + barra.get_width() / 2, altura),
                xytext=(0, 4),
                textcoords="offset points",
                ha="center",
                fontsize=9,
                fontweight="bold",
            )

        plt.tight_layout()

        buffer = io.BytesIO()
        plt.savefig(buffer, format="png", dpi=130)
        plt.close(fig)
        buffer.seek(0)
        return buffer.getvalue()