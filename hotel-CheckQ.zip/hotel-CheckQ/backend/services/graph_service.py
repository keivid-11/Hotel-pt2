from estructures.graph_geolocation import construir_grafo_maceio


class GrafoService:
    def __init__(self):
        self._grafo = construir_grafo_maceio()

    def listar_locais(self) -> list[dict]:
        return [
            {
                "nome": nome,
                "latitude": info["lat"],
                "longitude": info["lon"],
                "tipo": info["tipo"],
                "conexoes": list(self._grafo.adjacencias[nome].keys()),
            }
            for nome, info in self._grafo.vertices.items()
        ]

    def calcular_rota(self, origem: str, destino: str) -> dict:
        return self._grafo.menor_caminho_dijkstra(origem=origem, destino=destino)

    def gerar_mapa_rota(self, origem: str, destino: str) -> bytes:
        return self._grafo.gerar_mapa_matplotlib(origem=origem, destino=destino)