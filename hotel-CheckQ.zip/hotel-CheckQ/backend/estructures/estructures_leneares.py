from typing import Any, Optional


class No:
    """Nó básico para Lista Encadeada, Pilha e Deque."""
    def __init__(self, dado: Any):
        self.dado = dado
        self.proximo: Optional["No"] = None
        self.anterior: Optional["No"] = None


class ListaEncadeada:
    """Lista Simplesmente Encadeada."""
    def __init__(self):
        self.cabeca: Optional[No] = None
        self._tamanho: int = 0

    def inserir_fim(self, dado: Any) -> None:
        novo_no = No(dado)
        if self.cabeca is None:
            self.cabeca = novo_no
        else:
            atual = self.cabeca
            while atual.proximo is not None:
                atual = atual.proximo
            atual.proximo = novo_no
        self._tamanho += 1

    def listar_todos(self) -> list[Any]:
        elementos = []
        atual = self.cabeca
        while atual is not None:
            elementos.append(atual.dado)
            atual = atual.proximo
        return elementos

    def tamanho(self) -> int:
        return self._tamanho


class DequeFilaCheckin:
    """
    Deque (Double-Ended Queue) implementado com Lista Duplamente Encadeada.
    - Hóspedes normais entram no FIM (comportamento de Fila FIFO).
    - Hóspedes prioritários (idosos, gestantes, PCD, VIP) entram no INÍCIO.
    - O atendimento sempre remove do INÍCIO.
    """
    def __init__(self):
        self.inicio: Optional[No] = None
        self.fim: Optional[No] = None
        self._tamanho: int = 0

    def esta_vazia(self) -> bool:
        return self._tamanho == 0

    def tamanho(self) -> int:
        return self._tamanho

    def inserir_fim(self, dado: Any) -> None:
        """Enfileira atendimento normal no final."""
        novo_no = No(dado)
        if self.esta_vazia():
            self.inicio = self.fim = novo_no
        else:
            novo_no.anterior = self.fim
            self.fim.proximo = novo_no
            self.fim = novo_no
        self._tamanho += 1

    def inserir_inicio(self, dado: Any) -> None:
        """Insere atendimento prioritário na frente da fila."""
        novo_no = No(dado)
        if self.esta_vazia():
            self.inicio = self.fim = novo_no
        else:
            novo_no.proximo = self.inicio
            self.inicio.anterior = novo_no
            self.inicio = novo_no
        self._tamanho += 1

    def remover_inicio(self) -> Any:
        """Atende e remove o primeiro hóspede da fila."""
        if self.esta_vazia():
            raise IndexError("A fila/deque está vazia.")
        dado = self.inicio.dado
        self.inicio = self.inicio.proximo
        if self.inicio is None:
            self.fim = None
        else:
            self.inicio.anterior = None
        self._tamanho -= 1
        return dado

    def para_lista(self) -> list[Any]:
        """Converte os nós do Deque para uma lista Python para serialização JSON."""
        resultado = []
        atual = self.inicio
        while atual is not None:
            resultado.append(atual.dado)
            atual = atual.proximo
        return resultado

    def limpar(self) -> None:
        self.inicio = None
        self.fim = None
        self._tamanho = 0


class PilhaDesfazer:
    """
    Pilha (LIFO - Last In, First Out) implementada com nós encadeados.
    Armazena os check-ins recém-atendidos para permitir a função 'Desfazer' (Undo).
    """
    def __init__(self):
        self.topo: Optional[No] = None
        self._tamanho: int = 0

    def esta_vazia(self) -> bool:
        return self.topo is None

    def empilhar(self, dado: Any) -> None:
        """Push: adiciona um registro no topo da pilha."""
        novo_no = No(dado)
        novo_no.proximo = self.topo
        self.topo = novo_no
        self._tamanho += 1

    def desempilhar(self) -> Any:
        """Pop: remove e retorna o registro do topo da pilha."""
        if self.esta_vazia():
            raise IndexError("A pilha de desfazer está vazia.")
        dado = self.topo.dado
        self.topo = self.topo.proximo
        self._tamanho -= 1
        return dado

    def espiar_topo(self) -> Optional[Any]:
        """Peek: visualiza o último check-in atendido sem remover."""
        return self.topo.dado if self.topo else None

    def tamanho(self) -> int:
        return self._tamanho