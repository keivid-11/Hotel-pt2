import time
import random
from typing import Any, Callable


class ResultadoOrdenacao:
    def __init__(self, dados: list[Any], algoritmo: str, tempo_ms: float, comparacoes: int):
        self.dados = dados
        self.algoritmo = algoritmo
        self.tempo_ms = tempo_ms
        self.comparacoes = comparacoes


def bubble_sort(lista: list[Any], chave: Callable[[Any], Any]) -> ResultadoOrdenacao:
    """
    Método da Bolha (Bubble Sort) - Complexidade O(n²).
    Compara pares adjacentes e troca-os se estiverem fora de ordem.
    """
    arr = lista.copy()
    n = len(arr)
    comparacoes = 0
    inicio = time.perf_counter()

    for i in range(n):
        trocou = False
        for j in range(0, n - i - 1):
            comparacoes += 1
            if chave(arr[j]) > chave(arr[j + 1]):
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                trocou = True
        if not trocou:
            break

    tempo_ms = (time.perf_counter() - inicio) * 1000
    return ResultadoOrdenacao(arr, "Bubble Sort", tempo_ms, comparacoes)


def insertion_sort(lista: list[Any], chave: Callable[[Any], Any]) -> ResultadoOrdenacao:
    """
    Ordenação por Inserção (Insertion Sort) - Complexidade O(n²) no pior caso, O(n) quase ordenado.
    Constrói a lista ordenada um elemento por vez.
    """
    arr = lista.copy()
    n = len(arr)
    comparacoes = 0
    inicio = time.perf_counter()

    for i in range(1, n):
        atual = arr[i]
        valor_atual = chave(atual)
        j = i - 1

        while j >= 0:
            comparacoes += 1
            if chave(arr[j]) > valor_atual:
                arr[j + 1] = arr[j]
                j -= 1
            else:
                break
        arr[j + 1] = atual

    tempo_ms = (time.perf_counter() - inicio) * 1000
    return ResultadoOrdenacao(arr, "Insertion Sort", tempo_ms, comparacoes)


def selection_sort(lista: list[Any], chave: Callable[[Any], Any]) -> ResultadoOrdenacao:
    """
    Ordenação por Seleção (Selection Sort) - Complexidade O(n²).
    Busca repetidamente o menor elemento da parte não ordenada e coloca no início.
    """
    arr = lista.copy()
    n = len(arr)
    comparacoes = 0
    inicio = time.perf_counter()

    for i in range(n):
        indice_menor = i
        for j in range(i + 1, n):
            comparacoes += 1
            if chave(arr[j]) < chave(arr[indice_menor]):
                indice_menor = j
        if indice_menor != i:
            arr[i], arr[indice_menor] = arr[indice_menor], arr[i]

    tempo_ms = (time.perf_counter() - inicio) * 1000
    return ResultadoOrdenacao(arr, "Selection Sort", tempo_ms, comparacoes)


def quick_sort(lista: list[Any], chave: Callable[[Any], Any]) -> ResultadoOrdenacao:
    """
    QuickSort - Complexidade média O(n log n).
    Usa divisão e conquista escolhendo um pivô central para particionar os dados.
    """
    arr = lista.copy()
    comparacoes = 0
    inicio = time.perf_counter()

    def _quicksort_recursivo(sublista: list[Any]) -> list[Any]:
        nonlocal comparacoes
        if len(sublista) <= 1:
            return sublista

        pivo = sublista[len(sublista) // 2]
        valor_pivo = chave(pivo)

        menores = []
        iguais = []
        maiores = []

        for item in sublista:
            val = chave(item)
            comparacoes += 1
            if val < valor_pivo:
                menores.append(item)
            elif val > valor_pivo:
                comparacoes += 1
                maiores.append(item)
            else:
                comparacoes += 1
                iguais.append(item)

        return _quicksort_recursivo(menores) + iguais + _quicksort_recursivo(maiores)

    ordenado = _quicksort_recursivo(arr)
    tempo_ms = (time.perf_counter() - inicio) * 1000
    return ResultadoOrdenacao(ordenado, "QuickSort", tempo_ms, comparacoes)


def gerar_massa_checkins_simulados(quantidade: int) -> list[dict]:
    """Gera registros simulados de check-ins do hotel para benchmark de desempenho."""
    nomes = ["Ana", "Bruno", "Carlos", "Daniela", "Eduardo", "Fernanda", "Gabriel", "Helena", "Igor", "Juliana"]
    sobrenomes = ["Silva", "Santos", "Oliveira", "Souza", "Lima", "Pereira", "Costa", "Almeida"]
    registros = []
    for i in range(quantidade):
        registros.append({
            "id": i + 1,
            "nome_hospede": f"{random.choice(nomes)} {random.choice(sobrenomes)} #{random.randint(1, 9999)}",
            "numero_quarto": random.randint(1, 100),
        })
    return registros