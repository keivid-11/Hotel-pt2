from typing import Any, Optional


class TabelaHash:
    """
    Tabela Hash com Encadeamento Separado (Separate Chaining) para tratamento de colisões.
    Aplicada no Hotel CheckQ para:
    1. Mapeamento O(1) de quartos ocupados (Chave: numero_quarto -> Valor: dados do check-in).
    2. Indexação rápida de hóspedes por CPF (Chave: cpf -> Valor: dados do usuário).
    """

    def __init__(self, capacidade: int = 31):
        # Número primo reduz a taxa de colisões no método da divisão
        self.capacidade = capacidade
        self.buckets: list[list[tuple[Any, Any]]] = [[] for _ in range(capacidade)]
        self.total_elementos = 0
        self.total_colisoes = 0

    def _funcao_hash(self, chave: Any) -> int:
        """
        Função de espalhamento (Hash Function) pelo Método da Divisão:
        - Se a chave for inteira (ex: número do quarto), aplica chave % capacidade.
        - Se for string (ex: CPF), calcula hash polinomial antes do módulo.
        """
        if isinstance(chave, int):
            valor_numerico = abs(chave)
        else:
            texto = str(chave)
            valor_numerico = 0
            for caractere in texto:
                valor_numerico = (valor_numerico * 31 + ord(caractere))
        return valor_numerico % self.capacidade

    def inserir(self, chave: Any, valor: Any) -> None:
        """Insere ou atualiza um par (chave, valor) na Tabela Hash."""
        indice = self._funcao_hash(chave)
        bucket = self.buckets[indice]

        for i, (chave_existente, _) in enumerate(bucket):
            if chave_existente == chave:
                bucket[i] = (chave, valor)
                return

        if len(bucket) > 0:
            self.total_colisoes += 1

        bucket.append((chave, valor))
        self.total_elementos += 1

    def buscar(self, chave: Any) -> Optional[Any]:
        """Busca um valor pela chave em tempo médio O(1)."""
        indice = self._funcao_hash(chave)
        bucket = self.buckets[indice]

        for chave_existente, valor in bucket:
            if chave_existente == chave:
                return valor
        return None

    def contem(self, chave: Any) -> bool:
        """Verifica se a chave existe na Tabela Hash."""
        return self.buscar(chave) is not None

    def remover(self, chave: Any) -> bool:
        """Remove uma chave da Tabela Hash."""
        indice = self._funcao_hash(chave)
        bucket = self.buckets[indice]

        for i, (chave_existente, _) in enumerate(bucket):
            if chave_existente == chave:
                del bucket[i]
                self.total_elementos -= 1
                return True
        return False

    def limpar(self) -> None:
        self.buckets = [[] for _ in range(self.capacidade)]
        self.total_elementos = 0
        self.total_colisoes = 0

    def estado_tabela(self) -> dict:
        """Retorna métricas e distribuição dos buckets para inspeção/apresentação."""
        buckets_ocupados = {}
        for idx, bucket in enumerate(self.buckets):
            if bucket:
                buckets_ocupados[f"bucket_{idx}"] = [
                    {"chave": k, "valor": str(v)} for k, v in bucket
                ]
        return {
            "capacidade_buckets": self.capacidade,
            "total_elementos": self.total_elementos,
            "colisoes_registradas": self.total_colisoes,
            "fator_carga": round(self.total_elementos / self.capacidade, 2),
            "distribuicao": buckets_ocupados,
        }