import math
import heapq
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


class GrafoGeolocalizacao:
    """
    Grafo Ponderado Não-Direcionado implementado com Lista de Adjacências.
    - Vértices: Pontos geográficos (Hotel CheckQ e locais estratégicos de Maceió/AL) com (latitude, longitude).
    - Arestas: Vias de ligação ponderadas pela distância geográfica real (km) via Fórmula de Haversine.
    """

    def __init__(self):
        # {nome_local: {"lat": float, "lon": float, "tipo": str}}
        self.vertices: dict[str, dict] = {}
        # {origem: {destino: distancia_km}}
        self.adjacencias: dict[str, dict[str, float]] = {}

    def adicionar_local(self, nome: str, latitude: float, longitude: float, tipo: str = "Ponto Turístico") -> None:
        self.vertices[nome] = {
            "lat": latitude,
            "lon": longitude,
            "tipo": tipo,
        }
        if nome not in self.adjacencias:
            self.adjacencias[nome] = {}

    @staticmethod
    def _calcular_haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calcula a distância geodésica em quilômetros entre duas coordenadas (lat, lon)."""
        raio_terra_km = 6371.0
        d_lat = math.radians(lat2 - lat1)
        d_lon = math.radians(lon2 - lon1)

        a = (
            math.sin(d_lat / 2) ** 2
            + math.cos(math.radians(lat1))
            * math.cos(math.radians(lat2))
            * math.sin(d_lon / 2) ** 2
        )
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return round(raio_terra_km * c, 2)

    def conectar_locais(self, origem: str, destino: str, fator_rota: float = 1.25) -> None:
        """
        Cria uma aresta bidirecional entre dois vértices.
        O fator_rota (padrão 1.25) ajusta a distância em linha reta para a malha viária urbana.
        """
        if origem not in self.vertices or destino not in self.vertices:
            raise ValueError(f"Vértice não encontrado: {origem} ou {destino}")

        v1 = self.vertices[origem]
        v2 = self.vertices[destino]
        distancia = round(self._calcular_haversine_km(v1["lat"], v1["lon"], v2["lat"], v2["lon"]) * fator_rota, 2)

        self.adjacencias[origem][destino] = distancia
        self.adjacencias[destino][origem] = distancia

    def menor_caminho_dijkstra(self, origem: str, destino: str) -> dict:
        """
        Algoritmo de Dijkstra utilizando fila de prioridade (min-heap)
        para encontrar o trajeto mais curto entre origem e destino.
        """
        if origem not in self.vertices:
            raise ValueError(f"Local de origem inválido: '{origem}'")
        if destino not in self.vertices:
            raise ValueError(f"Local de destino inválido: '{destino}'")

        distancias = {vertice: float("inf") for vertice in self.vertices}
        anteriores: dict[str, str | None] = {vertice: None for vertice in self.vertices}
        distancias[origem] = 0.0

        fila_prioridade: list[tuple[float, str]] = [(0.0, origem)]

        while fila_prioridade:
            dist_atual, vertice_atual = heapq.heappop(fila_prioridade)

            if vertice_atual == destino:
                break

            if dist_atual > distancias[vertice_atual]:
                continue

            for vizinho, peso in self.adjacencias[vertice_atual].items():
                nova_dist = dist_atual + peso
                if nova_dist < distancias[vizinho]:
                    distancias[vizinho] = nova_dist
                    anteriores[vizinho] = vertice_atual
                    heapq.heappush(fila_prioridade, (nova_dist, vizinho))

        if distancias[destino] == float("inf"):
            raise ValueError(f"Não existe rota conectando '{origem}' até '{destino}'.")

        caminho = []
        atual: str | None = destino
        while atual is not None:
            caminho.insert(0, atual)
            atual = anteriores[atual]

        trechos = []
        for i in range(len(caminho) - 1):
            u, v = caminho[i], caminho[i + 1]
            trechos.append({
                "de": u,
                "para": v,
                "distancia_km": self.adjacencias[u][v],
            })

        return {
            "origem": origem,
            "destino": destino,
            "distancia_total_km": round(distancias[destino], 2),
            "tempo_estimado_min": round((distancias[destino] / 40.0) * 60),  # média urbana 40 km/h
            "caminho": caminho,
            "trechos": trechos,
        }

    def gerar_mapa_matplotlib(self, origem: str, destino: str) -> bytes:
        """
        Plota o grafo geográfico (Longitude x Latitude) via Matplotlib,
        destacando o menor caminho calculado pelo Dijkstra.
        """
        resultado_rota = self.menor_caminho_dijkstra(origem, destino)
        caminho_destaque = resultado_rota["caminho"]
        arestas_destaque = set()
        for i in range(len(caminho_destaque) - 1):
            u, v = caminho_destaque[i], caminho_destaque[i + 1]
            arestas_destaque.add((u, v))
            arestas_destaque.add((v, u))

        fig, ax = plt.subplots(figsize=(11, 7))
        fig.patch.set_facecolor("#f8fafc")
        ax.set_facecolor("#f1f5f9")

        # 1. Desenha todas as arestas do grafo
        desenhadas = set()
        for u, vizinhos in self.adjacencias.items():
            for v, peso in vizinhos.items():
                if (v, u) in desenhadas:
                    continue
                desenhadas.add((u, v))

                lon1, lat1 = self.vertices[u]["lon"], self.vertices[u]["lat"]
                lon2, lat2 = self.vertices[v]["lon"], self.vertices[v]["lat"]

                eh_rota = (u, v) in arestas_destaque
                cor = "#dc2626" if eh_rota else "#94a3b8"
                largura = 3.2 if eh_rota else 1.2
                estilo = "-" if eh_rota else "--"
                z = 4 if eh_rota else 1

                ax.plot([lon1, lon2], [lat1, lat2], color=cor, linewidth=largura, linestyle=estilo, zorder=z)

                # Rótulo de distância no meio da aresta
                meio_lon = (lon1 + lon2) / 2
                meio_lat = (lat1 + lat2) / 2
                ax.text(
                    meio_lon,
                    meio_lat,
                    f"{peso} km",
                    fontsize=7.5,
                    color="#991b1b" if eh_rota else "#475569",
                    fontweight="bold" if eh_rota else "normal",
                    bbox=dict(boxstyle="round,pad=0.15", facecolor="white", edgecolor="none", alpha=0.8),
                    zorder=5,
                )

        # 2. Desenha os vértices (locais)
        for nome, info in self.vertices.items():
            lon, lat = info["lon"], info["lat"]
            if nome == origem:
                cor_no, tamanho, marcador = "#0284c7", 180, "s"
            elif nome == destino:
                cor_no, tamanho, marcador = "#16a34a", 180, "^"
            elif nome in caminho_destaque:
                cor_no, tamanho, marcador = "#dc2626", 110, "o"
            else:
                cor_no, tamanho, marcador = "#334155", 85, "o"

            ax.scatter(lon, lat, s=tamanho, color=cor_no, marker=marcador, edgecolors="white", linewidth=1.8, zorder=6)
            ax.annotate(
                nome,
                (lon, lat),
                xytext=(0, 9),
                textcoords="offset points",
                ha="center",
                fontsize=8.5,
                fontweight="bold",
                color="#0f172a",
                bbox=dict(boxstyle="round,pad=0.2", facecolor="white", edgecolor="#cbd5e1", alpha=0.92),
                zorder=7,
            )

        ax.set_title(
            f"Hotel CheckQ — Grafo de Geolocalização (Dijkstra)\n"
            f"Rota: {origem} → {destino} | Distância Total: {resultado_rota['distancia_total_km']} km "
            f"(~{resultado_rota['tempo_estimado_min']} min)",
            fontsize=11.5,
            fontweight="bold",
            pad=14,
        )
        ax.set_xlabel("Longitude")
        ax.set_ylabel("Latitude")
        ax.grid(True, linestyle=":", alpha=0.6)

        # Legenda manual
        from matplotlib.lines import Line2D
        legenda = [
            Line2D([0], [0], marker="s", color="w", label=f"Origem ({origem})", markerfacecolor="#0284c7", markersize=10),
            Line2D([0], [0], marker="^", color="w", label=f"Destino ({destino})", markerfacecolor="#16a34a", markersize=10),
            Line2D([0], [0], color="#dc2626", lw=3, label="Menor Caminho (Dijkstra)"),
            Line2D([0], [0], color="#94a3b8", lw=1.2, ls="--", label="Outras Vias do Grafo"),
        ]
        ax.legend(handles=legenda, loc="lower right", framealpha=0.95, fontsize=8.5)

        plt.tight_layout()
        buffer = io.BytesIO()
        plt.savefig(buffer, format="png", dpi=130)
        plt.close(fig)
        buffer.seek(0)
        return buffer.getvalue()


def construir_grafo_maceio() -> GrafoGeolocalizacao:
    """Instancia o grafo turístico/logístico ao redor do Hotel CheckQ em Maceió."""
    grafo = GrafoGeolocalizacao()

    # Coordenadas reais aproximadas em Maceió - AL
    grafo.adicionar_local("Hotel CheckQ (Ponta Verde)", -9.6648, -35.7012, "Hotel")
    grafo.adicionar_local("Praia de Pajuçara", -9.6735, -35.7145, "Praia")
    grafo.adicionar_local("Centro Histórico / Jaraguá", -9.6712, -35.7368, "Turismo")
    grafo.adicionar_local("Parque Shopping Maceió", -9.6265, -35.6989, "Shopping")
    grafo.adicionar_local("Terminal Rodoviário", -9.6345, -35.7248, "Transporte")
    grafo.adicionar_local("Praia de Jacarecica", -9.6105, -35.6915, "Praia")
    grafo.adicionar_local("Aeroporto Zumbi dos Palmares", -9.5108, -35.7917, "Aeroporto")
    grafo.adicionar_local("Praia do Francês", -9.7689, -35.8405, "Praia")

    # Conexões viárias (arestas)
    grafo.conectar_locais("Hotel CheckQ (Ponta Verde)", "Praia de Pajuçara")
    grafo.conectar_locais("Hotel CheckQ (Ponta Verde)", "Parque Shopping Maceió")
    grafo.conectar_locais("Hotel CheckQ (Ponta Verde)", "Terminal Rodoviário")
    grafo.conectar_locais("Praia de Pajuçara", "Centro Histórico / Jaraguá")
    grafo.conectar_locais("Centro Histórico / Jaraguá", "Terminal Rodoviário")
    grafo.conectar_locais("Centro Histórico / Jaraguá", "Praia do Francês")
    grafo.conectar_locais("Parque Shopping Maceió", "Praia de Jacarecica")
    grafo.conectar_locais("Parque Shopping Maceió", "Terminal Rodoviário")
    grafo.conectar_locais("Terminal Rodoviário", "Aeroporto Zumbi dos Palmares")
    grafo.conectar_locais("Praia de Jacarecica", "Aeroporto Zumbi dos Palmares")

    return grafo